from django.http.request import HttpRequest
from django.shortcuts import render
from django.http import HttpResponse
from . models import Product
from math import ceil
# Create your views here.

def index(request):
    products= Product.objects.all()
    context={'products': products}
    return render(request, "shop/shop.html", context)

def checkout(request,product_name):
    product=Product.objects.filter(product_name=product_name).first()
    # print(product)
    context={'product': product , 'user': request.user}
    return render(request, "shop/checkout.html",context)

def order(request):
    return HttpResponse('order')

