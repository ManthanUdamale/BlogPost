from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="ShopHome"),
    # path('tracker/', views.tracker, name="TrackingStatus"),
    path('shop/', views.order, name="Order"),
    # path('products/<int:myid>', views.productView, name="Search"),
    path('<str:product_name>', views.checkout , name="Checkout"),
]